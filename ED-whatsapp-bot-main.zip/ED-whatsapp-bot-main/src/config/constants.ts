export const modes = {
  mode_1: 'mode 1',
  mode_2: 'mode 2',
};

export const Actions = {
  SHOW_MENU: 'continuegreeting',
  THEME: {
    
  }
}

export const THEME_TEMPLATE_ID = 'HX2510ee3253420e9d2d7159697ec6d383'
export const GREETING_TEMPLATE_ID = 'HX6b2fe3b249863d69dee3888bfa54dffa'